#!/usr/bin/env python3
"""Untouched source, matched setup/imports, native profile without Firefox trace."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

repo = Path(__file__).resolve().parents[2]
campaign = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('profile_elaboration', repo / 'scripts/profile_elaboration.py')
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)
original = campaign / 'profiles-after'
record = json.loads((original / 'profiles.json').read_text())[-1]
assert record['module'] == 'Cloning.PhysicalFlatConverseReduction' and record['exit_code'] == 1
output = campaign / 'native-profile-control'
output.mkdir(exist_ok=False)
for key in ('setup_snapshot', 'trace_snapshot'):
    shutil.copyfile(original / record[key], output / record[key])
setup = json.loads((output / record['setup_snapshot']).read_text())
env = os.environ.copy()
env.update(LEAN_NUM_THREADS='2', LAKE_ARTIFACT_CACHE='false')
lake = shutil.which('lake') or str(Path.home() / '.elan/bin/lake')
effective = p.effective_environment(lake, env)
before, mapped = p.import_context(lake, record['source'], setup, effective, env)
assert p.sha256(p.PROJECT / record['source']) == record['source_sha256']
assert p.config_hashes() == record['config_sha256']
label = 'Cloning.PhysicalFlatConverseReduction-native-1'
log = output / (label + '.log')
resources = output / (label + '.resources.txt')
command = ['/opt/homebrew/bin/gtime', '-v', '-o', str(resources), lake, 'env', 'lean',
           '-DautoImplicit=false', '--profile', '--stats', '--setup',
           str(output / record['setup_snapshot']), record['source']]
start = datetime.now(timezone.utc).isoformat()
clock = time.monotonic()
with log.open('w') as stream:
    result = subprocess.run(command, cwd=p.PROJECT, env=env, stdout=stream, stderr=subprocess.STDOUT)
wall = time.monotonic() - clock
end = datetime.now(timezone.utc).isoformat()
after, _ = p.import_context(lake, record['source'], setup, effective, env)
stable = before == after and p.config_hashes() == record['config_sha256'] and p.sha256(p.PROJECT / record['source']) == record['source_sha256']
context = output / (label + '.import-context.json')
context.write_text(json.dumps({'before': before, 'after': after,
    'mapped_artifact_metadata_rows_before': mapped, 'notes': ['Native-only control; same import guard as the traced attempt.']}, indent=2) + '\n')
record.update(command=command, start_utc=start, end_utc=end, wall_seconds=wall,
    exit_code=result.returncode, log=log.name, resources=resources.name, events=None,
    trace_mode='native', environment=effective['environment'], toolchain=effective,
    import_context=context.name, import_context_sha256=p.sha256(context),
    inputs_stable=stable, measurement_valid=result.returncode == 0 and stable,
    original_failed_index_sha256=p.sha256(original / 'profiles.json'),
    original_failed_record_position=11, native_control_driver_sha256=p.sha256(Path(__file__)),
    notes=['No proof, heartbeat, or source option changed; omitted only Firefox trace flags.'])
(output / 'profiles.json').write_text(json.dumps([record], indent=2) + '\n')
print(json.dumps({'module': record['module'], 'exit_code': result.returncode,
    'wall_seconds': wall, 'inputs_stable': stable}), flush=True)
raise SystemExit(result.returncode)
