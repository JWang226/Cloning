#!/usr/bin/env python3
"""One hash-bound, sequential proof diagnostic and alternating A/B experiment.

This ignored campaign driver never compiles imports or writes owned artifacts.
It refuses to create Lean experiment copies until the full before gates pass.
"""
import difflib
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
from datetime import datetime, timezone

REPO = Path(__file__).resolve().parents[2]
CAMPAIGN = REPO / '.verify-work/elaboration-campaign'
PROJECT = REPO / 'formalization'
MODULE = 'Cloning.WeylIdlerUniqueness'
SOURCE = 'Cloning/WeylIdlerUniqueness.lean'


def load(name):
    spec = importlib.util.spec_from_file_location(name, REPO / 'scripts' / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def gate():
    before = json.loads((CAMPAIGN / 'before/summary.json').read_text())
    stability = json.loads((CAMPAIGN / 'before/source-config-stability.json').read_text())
    profiles = json.loads((CAMPAIGN / 'profiles-before/summary.json').read_text())
    assert before['exit_code'] == 0 and before['dependency_artifacts_unchanged']
    assert not before.get('upstream_compilations')
    assert stability['unchanged'] is True and stability['commit'] == before['commit']
    assert profiles['schema'] == 'cloning-elaboration-profile-summary-v1'
    assert profiles['profile_count'] == 10 and len(profiles['profiles']) == 10
    for row in profiles['profiles']:
        p = row['profile']
        assert p['exit_code'] == 0 and p['measurement_valid'] and p['inputs_stable']
        assert p['source_matches_benchmark'] and p['config_matches_benchmark']
        assert all(p[k] for k in ['config_hashes_unchanged', 'source_hash_unchanged',
            'import_artifacts_unchanged', 'build_setup_unchanged', 'build_trace_unchanged'])
    return before


def main():
    before = gate()
    helper = load('profile_elaboration')
    out = CAMPAIGN / 'weyl-bridge-ab'
    if out.exists():
        raise RuntimeError('Refusing to overwrite experimental evidence')
    out.mkdir()
    original = (PROJECT / SOURCE).read_bytes()
    assert original == helper.git_source(before['commit'], SOURCE)
    old = '    intro x\n    change (∫ a : Fin d → ℂ,'.encode()
    new = '    intro x\n    rw [show vectorProjector x = rankOneOperator x x from rfl]\n    change (∫ a : Fin d → ℂ,'.encode()
    assert original.count(old) == 1
    bridge = original.replace(old, new)
    text = original.decode()
    begin = text.index('theorem integral_weighted_characteristic ')
    proof = text.index(' := by', begin) + len(' := ')
    end = text.index('\n/-- Left and right displacement', proof)
    diagnostic = (text[:proof] + 'by\n  sorry\n' + text[end:]).encode()
    variants = {'A': original, 'B': bridge, 'diagnostic': diagnostic}
    for name, data in variants.items():
        (out / (name + '.source.lean.txt')).write_bytes(data)
    patch = ''.join(difflib.unified_diff(original.decode().splitlines(True),
        bridge.decode().splitlines(True), 'a/formalization/' + SOURCE,
        'b/formalization/' + SOURCE))
    (out / 'candidate.patch').write_text(patch)
    entry = out / 'WeylIdlerUniqueness.lean'
    setup_original = PROJECT / '.lake/build/ir/Cloning/WeylIdlerUniqueness.setup.json'
    trace_original = PROJECT / '.lake/build/lib/lean/Cloning/WeylIdlerUniqueness.trace'
    setup_bytes, trace_bytes = setup_original.read_bytes(), trace_original.read_bytes()
    setup = json.loads(setup_bytes)
    assert setup['name'] == MODULE and setup.get('imports') is None
    (out / 'setup.json').write_bytes(setup_bytes)
    (out / 'build-trace.json').write_bytes(trace_bytes)
    lake = shutil.which('lake') or str(Path.home() / '.elan/bin/lake')
    env = os.environ.copy()
    env.update(LEAN_NUM_THREADS='2', LAKE_ARTIFACT_CACHE='false')
    effective = helper.effective_environment(lake, env)
    config_before = helper.config_hashes()
    benchmark_configs = {'formalization/' + name: sha(helper.git_source(before['commit'], name))
        for name in helper.CONFIGS}
    assert config_before == benchmark_configs
    commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
    profiles, bare = [], []
    write_json(out / 'plan.json', {'schema': 'cloning-weyl-bridge-ab-plan-v1',
        'benchmark_commit': before['commit'], 'current_commit': commit,
        'script_sha256': helper.sha256(Path(__file__)),
        'variant_sha256': {name: sha(data) for name, data in variants.items()},
        'setup_sha256': sha(setup_bytes), 'build_trace_sha256': sha(trace_bytes),
        'config_sha256': config_before, 'toolchain': effective,
        'environment_overrides': {'LEAN_NUM_THREADS': '2', 'LAKE_ARTIFACT_CACHE': 'false'},
        'order': ['diagnostic-profile'] + [f'{a}{r}-profile' for r in range(1,4) for a in ['A','B']]
            + [f'{a}{r}-bare' for r in range(1,4) for a in ['A','B']],
        'notes': ['Both A/B arms use the same experimental entry path and setup module name.',
            'Profiles use pp=false in both arms to avoid pretty-printer costs; repository profiles use pp=true.',
            'Bare pairs omit profile, trace and statistics; their native GNU CPU is the compiler control.',
            'The single sorry diagnostic exists only in ignored evidence and is not an accepted proof.']})

    def run(arm, repetition, mode):
        label = arm + '-' + str(repetition) + '-' + mode
        source_bytes = variants[arm]
        entry.write_bytes(source_bytes)
        context_before, mapped_rows = helper.import_context(lake, str(entry), setup, effective, env)
        log, resources, events = out / (label + '.log'), out / (label + '.resources.txt'), out / (label + '.json')
        command = ['/opt/homebrew/bin/gtime', '-v', '-o', str(resources), lake,
            'env', 'lean', '-DautoImplicit=false']
        if mode == 'profile':
            command += ['--profile', '--stats', '-Dtrace.profiler=true',
                '-Dtrace.profiler.output.pp=false', '-Dtrace.profiler.output=' + str(events)]
        command += ['--setup', str(out / 'setup.json'), str(entry)]
        print('Starting ' + label, flush=True)
        start = datetime.now(timezone.utc).isoformat()
        clock = time.monotonic()
        with log.open('w') as stream:
            completed = subprocess.run(command, cwd=PROJECT, env=env, stdout=stream, stderr=subprocess.STDOUT)
        wall = time.monotonic() - clock
        context_after, _ = helper.import_context(lake, str(entry), setup, effective, env)
        checks = {'config_hashes_unchanged': helper.config_hashes() == config_before,
            'source_hash_unchanged': entry.read_bytes() == source_bytes,
            'import_artifacts_unchanged': context_before == context_after,
            'build_setup_unchanged': setup_original.read_bytes() == setup_bytes,
            'build_trace_unchanged': trace_original.read_bytes() == trace_bytes,
            'tracked_source_unchanged': (PROJECT / SOURCE).read_bytes() == original}
        context_file = out / (label + '.import-context.json')
        write_json(context_file, {'before': context_before, 'after': context_after,
            'mapped_artifact_metadata_rows_before': mapped_rows})
        result = {'module': MODULE, 'repetition': repetition, 'arm': arm, 'mode': mode,
            'source': SOURCE, 'source_sha256': sha(source_bytes),
            'source_snapshot': arm + '.source.lean.txt', 'entry_path': str(entry),
            'commit': commit, 'benchmark_commit': before['commit'],
            'source_matches_commit': source_bytes == helper.git_source(commit, SOURCE),
            'source_matches_benchmark': source_bytes == original,
            'setup_snapshot': 'setup.json', 'setup_sha256': sha(setup_bytes),
            'trace_snapshot': 'build-trace.json', 'trace_sha256': sha(trace_bytes),
            'import_context': context_file.name, 'import_context_sha256': helper.sha256(context_file),
            'environment': effective['environment'], 'toolchain': effective,
            'environment_overrides': {'LEAN_NUM_THREADS': '2', 'LAKE_ARTIFACT_CACHE': 'false'},
            'config_sha256': config_before, 'config_matches_benchmark': True,
            'command': command, 'start_utc': start, 'end_utc': datetime.now(timezone.utc).isoformat(),
            'wall_seconds': wall, 'exit_code': completed.returncode,
            'log': log.name, 'resources': resources.name, **checks}
        result['inputs_stable'] = all(checks.values())
        result['measurement_valid'] = completed.returncode == 0 and result['inputs_stable']
        if mode == 'profile':
            result['events'] = events.name
            profiles.append(result)
            write_json(out / 'profiles.json', profiles)
        else:
            bare.append(result)
            write_json(out / 'bare.json', bare)
        print(f"Finished {label}: exit {completed.returncode}, {wall:.2f}s", flush=True)
        if not result['measurement_valid']:
            raise RuntimeError('Invalid measurement; no further runs: ' + label)

    run('diagnostic', 1, 'profile')
    summarizer = load('summarize_elaboration_profiles')
    diagnostic_profile = summarizer.parse_text_profile(
        (out / 'diagnostic-1-profile.log').read_text())
    baseline_profile = json.loads((CAMPAIGN / 'profiles-before/summary.json').read_text())
    baseline_phase = next(row['text_profile']['exclusive_phase_ms']['tactic execution']
        for row in baseline_profile['profiles'] if row['profile']['module'] == MODULE)
    diagnostic_phase = diagnostic_profile['exclusive_phase_ms'].get('tactic execution', 0)
    write_json(out / 'proof-vs-statement-diagnostic.json', {
        'diagnostic_text_profile': diagnostic_profile,
        'before_tactic_execution_ms': baseline_phase,
        'diagnostic_tactic_execution_ms': diagnostic_phase,
        'proof_cost_confirmed': diagnostic_phase < baseline_phase / 2,
        'note': 'pp differs from repository baseline; compare exclusive tactic phase, not whole-process time.'})
    print(f'Diagnostic tactic phase: {diagnostic_phase}ms versus before {baseline_phase}ms', flush=True)
    if diagnostic_phase >= baseline_phase / 2:
        raise RuntimeError('Proof-cost diagnostic failed; do not proceed to proof intervention')
    for mode in ['profile', 'bare']:
        for repetition in range(1, 4):
            for arm in ['A', 'B']:
                run(arm, repetition, mode)
    entry.write_bytes(original)
    print('All diagnostic and paired runs complete; tracked source remains unchanged.', flush=True)


if __name__ == '__main__':
    main()
